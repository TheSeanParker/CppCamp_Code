#include<iostream>
using namespace std;

int main()
{

    int len=10;

    int *a;

    for(int i=0;i<100;i++)
    {
        cout<<a[i]<<endl;
    }
}