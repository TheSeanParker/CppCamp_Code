

using Predict=bool (*)(int , int );
using Handler=void (*)(int, int);



void print(int data1, int data2)
{
    cout<<"["<<pos<<"]"<<data1<<data2;
}